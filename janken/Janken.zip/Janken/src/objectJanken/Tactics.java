package objectJanken;

public interface Tactics {


	public int readTactics();
}
