package simpleJanken;

import org.junit.Test;


public class NonObjectJankenTest {

	@Test
	public void test(){
		NonObjectJanken testClass = new NonObjectJanken();
		testClass.janken();
	}

}
